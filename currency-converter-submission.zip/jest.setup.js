import '@testing-library/jest-dom'

// Mock environment variables
process.env.EXCHANGE_API_KEY = '93ab842346294a4292017b22b39e6a37'